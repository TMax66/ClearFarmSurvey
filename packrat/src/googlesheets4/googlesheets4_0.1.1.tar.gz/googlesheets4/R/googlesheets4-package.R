#' @keywords internal
#' @importFrom purrr %||% map_lgl map_int map_dbl map_chr map map2 pluck
"_PACKAGE"
